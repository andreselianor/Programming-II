﻿namespace AutosLocos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Race.LaunchGame();
        }
    }
}