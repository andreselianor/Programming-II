﻿namespace AutosLocos
{
    public class Human : Driver
    {
        public override double GetVelocityExtra()
        {
            return 0.0;
        }
    }
}