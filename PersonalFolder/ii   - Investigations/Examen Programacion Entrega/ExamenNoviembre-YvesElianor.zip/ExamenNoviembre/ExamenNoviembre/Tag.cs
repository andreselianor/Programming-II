﻿namespace ExamenNoviembre
{
    public class Tag
    {
    }
}
