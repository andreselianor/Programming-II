﻿namespace ExamenCrazyRace
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Simulacion de carreras CrazyRunners");
        }
    }
}