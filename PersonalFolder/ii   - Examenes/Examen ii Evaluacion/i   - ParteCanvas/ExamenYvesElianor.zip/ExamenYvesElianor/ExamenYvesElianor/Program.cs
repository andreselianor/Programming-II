﻿namespace ExamenYvesElianor
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}